package bean;

import java.io.Serializable;

public class AccountBean implements Serializable {

    private int accountNo;
    private String name;
    private double balance;

    // No-argument constructor
    public AccountBean() {
        balance = 0.0;
    }

    // Getter for accountNo
    public int getAccountNo() {
        return accountNo;
    }

    // Setter for accountNo
    public void setAccountNo(int accountNo) {
        this.accountNo = accountNo;
    }

    // Getter for name
    public String getName() {
        return name;
    }

    // Setter for name
    public void setName(String name) {
        this.name = name;
    }

    // Getter for balance
    public double getBalance() {
        return balance;
    }

    // Deposit method
    public void deposit(double amount) {
        balance += amount;
    }

    // Withdraw method (returns true if successful)
    public boolean withdraw(double amount) {
        if (amount <= balance) {
            balance -= amount;
            return true;
        }
        return false;
    }
}