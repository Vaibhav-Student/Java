<%@ page import="java.sql.*" %>
<%@ page session="true" %>

<%
String username = request.getParameter("username");
String password = request.getParameter("password");

try{
    Class.forName("com.mysql.cj.jdbc.Driver");

    Connection con = DriverManager.getConnection(
        "jdbc:mysql://localhost:3307/jsp_db",
        "root",
        ""
    );

    PreparedStatement ps = con.prepareStatement(
        "SELECT * FROM login WHERE username=? AND password=?"
    );

    ps.setString(1, username);
    ps.setString(2, password);

    ResultSet rs = ps.executeQuery();

    if(rs.next()){
        session.setAttribute("user", username);   // FIXED
        response.sendRedirect("login.jsp");
    }else{
        out.println("<h3>Invalid Username or Password!</h3>");
        out.println("<a href='index.html'>Try Again</a>");
    }

    con.close();

}catch(Exception e){
    out.println(e);
}
%>