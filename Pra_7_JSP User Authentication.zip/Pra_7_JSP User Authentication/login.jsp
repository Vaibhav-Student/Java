<%@ page session="true" %>
<html>
<body>

<%
String user = (String) session.getAttribute("user");
if(user != null){
%>
    <h2>Welcome <%= user %></h2>
    <a href="index.html">Logout</a>
<%
}else{
    response.sendRedirect("index.html");
}
%>

</body>
</html>